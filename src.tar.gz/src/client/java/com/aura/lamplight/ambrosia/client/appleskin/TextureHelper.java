package com.aura.lamplight.ambrosia.client.appleskin;

import net.minecraft.resources.Identifier;

/**
 * Identifiers for the vanilla food/heart sprites the overlays draw on top of,
 * plus the custom icon sheet for the saturation and exhaustion bars.
 */
public final class TextureHelper {
    private TextureHelper() {
    }

    public static final Identifier MOD_ICONS = Identifier.fromNamespaceAndPath("lamplight", "textures/appleskin/icons.png");

    // Hunger
    public static final Identifier FOOD_EMPTY_HUNGER_TEXTURE = Identifier.withDefaultNamespace("hud/food_empty_hunger");
    public static final Identifier FOOD_HALF_HUNGER_TEXTURE = Identifier.withDefaultNamespace("hud/food_half_hunger");
    public static final Identifier FOOD_FULL_HUNGER_TEXTURE = Identifier.withDefaultNamespace("hud/food_full_hunger");
    public static final Identifier FOOD_EMPTY_TEXTURE = Identifier.withDefaultNamespace("hud/food_empty");
    public static final Identifier FOOD_HALF_TEXTURE = Identifier.withDefaultNamespace("hud/food_half");
    public static final Identifier FOOD_FULL_TEXTURE = Identifier.withDefaultNamespace("hud/food_full");

    public enum FoodType {
        EMPTY,
        HALF,
        FULL
    }

    /**
     * Returns the food sprite identifier for the given food state, using the
     * rotten variants when the food is rotten.
     *
     * @param isRotten whether to use the rotten-food sprites
     * @param type     the food icon state (empty/half/full)
     */
    public static Identifier getFoodTexture(boolean isRotten, FoodType type) {
        return switch (type) {
            case EMPTY -> isRotten ? FOOD_EMPTY_HUNGER_TEXTURE : FOOD_EMPTY_TEXTURE;
            case HALF -> isRotten ? FOOD_HALF_HUNGER_TEXTURE : FOOD_HALF_TEXTURE;
            case FULL -> isRotten ? FOOD_FULL_HUNGER_TEXTURE : FOOD_FULL_TEXTURE;
        };
    }

    // Hearts
    public static final Identifier HEART_CONTAINER = Identifier.withDefaultNamespace("hud/heart/container");
    public static final Identifier HEART_HARDCORE_CONTAINER = Identifier.withDefaultNamespace("hud/heart/container_hardcore");
    public static final Identifier HEART_FULL = Identifier.withDefaultNamespace("hud/heart/full");
    public static final Identifier HEART_HARDCORE_FULL = Identifier.withDefaultNamespace("hud/heart/hardcore_full");
    public static final Identifier HEART_HALF = Identifier.withDefaultNamespace("hud/heart/half");
    public static final Identifier HEART_HARDCORE_HALF = Identifier.withDefaultNamespace("hud/heart/hardcore_half");

    public enum HeartType {
        CONTAINER,
        FULL,
        HALF
    }

    /**
     * Returns the heart sprite identifier for the given heart state, using the
     * hardcore variants when the world is hardcore.
     *
     * @param hardcore whether to use the hardcore sprites
     * @param type     the heart icon state (container/full/half)
     */
    public static Identifier getHeartTexture(boolean hardcore, HeartType type) {
        return switch (type) {
            case CONTAINER -> hardcore ? HEART_HARDCORE_CONTAINER : HEART_CONTAINER;
            case FULL -> hardcore ? HEART_HARDCORE_FULL : HEART_FULL;
            case HALF -> hardcore ? HEART_HARDCORE_HALF : HEART_HALF;
        };
    }
}
