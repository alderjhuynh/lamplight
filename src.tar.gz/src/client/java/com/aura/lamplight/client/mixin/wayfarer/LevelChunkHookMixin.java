package com.aura.lamplight.client.mixin.wayfarer;

import com.aura.lamplight.wayfarer.client.world.ChunkDirtyTracker;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LevelChunk.class)
public class LevelChunkHookMixin {
    @Inject(method = "setBlockState", at = @At("RETURN"))
    private void wayfarer$onSetBlock(BlockPos pos, BlockState state, int flags, CallbackInfoReturnable<BlockState> cir) {
        LevelChunk self = (LevelChunk) (Object) this;

        if (self.getLevel() != null && self.getLevel().isClientSide()) {
            ChunkDirtyTracker.markDirty(self.getPos().x(), self.getPos().z());
        }
    }
}
