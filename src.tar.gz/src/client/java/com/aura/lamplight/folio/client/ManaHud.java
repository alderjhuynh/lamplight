package com.aura.lamplight.folio.client;

import com.aura.lamplight.folio.attribute.FolioAttributes;
import com.aura.lamplight.folio.spell.Spell;
import com.aura.lamplight.folio.spell.Spells;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;

/**
 * Draws the mana bar (and a cast bar while casting) just above the hotbar.
 * Mana is read straight from the synced player attributes, so this element
 * never needs a server tick or a bespoke packet.
 */
public final class ManaHud implements HudElement {

    private static final int BAR_WIDTH = 90;
    private static final int BAR_HEIGHT = 5;
    private static final int BACKDROP = 0x90000000;
    private static final int MANA = 0xFF3D6FE0;
    private static final int MANA_HIGHLIGHT = 0x60FFFFFF;
    private static final int CAST = 0xFFE0A040;

    @Override
    public void extractRenderState(final GuiGraphicsExtractor gfx, final DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) {
            return;
        }
        if (client.player.isSpectator()) {
            return;
        }

        AttributeInstance manaAttribute = client.player.getAttribute(
            BuiltInRegistries.ATTRIBUTE.wrapAsHolder(FolioAttributes.MANA));
        AttributeInstance maxAttribute = client.player.getAttribute(
            BuiltInRegistries.ATTRIBUTE.wrapAsHolder(FolioAttributes.MAX_MANA));
        if (manaAttribute == null || maxAttribute == null) {
            return;
        }

        double max = Math.max(0.0D, maxAttribute.getValue());
        if (max <= 0.0D) {
            return;
        }
        double mana = Math.max(0.0D, Math.min(max, manaAttribute.getValue()));

        if (!SpellbookClientState.hasSpellbook() && !SpellbookClientState.isCasting() && mana >= max) {
            return;
        }

        int centerX = gfx.guiWidth() / 2;
        int width = BAR_WIDTH;
        int x = centerX - width / 2;
        int y = gfx.guiHeight() - 44;

        float ratio = (float) (mana / max);
        gfx.fill(x - 1, y - 1, x + width + 1, y + BAR_HEIGHT + 1, BACKDROP);
        gfx.fill(x, y, x + Math.round(width * ratio), y + BAR_HEIGHT, MANA);
        gfx.fill(x, y, x + width, y + 1, MANA_HIGHLIGHT);

        gfx.text(client.font,
            Component.literal((int) Math.ceil(mana) + "/" + (int) Math.ceil(max)),
            x + width + 4, y - 2, 0xFFBBD4FF, true);

        if (SpellbookClientState.isCasting()) {
            int castY = y - 14;
            float progress = SpellbookClientState.castProgress();
            gfx.fill(x - 1, castY - 1, x + width + 1, castY + 5, BACKDROP);
            gfx.fill(x, castY, x + Math.round(width * progress), castY + 4, CAST);

            Spell spell = Spells.byId(Identifier.tryParse(SpellbookClientState.castingSpell()));
            Component name = spell == null
                ? Component.literal(SpellbookClientState.castingSpell())
                : spell.name();
            gfx.centeredText(client.font, name, centerX, castY - 10, 0xFFFFE0A0);
        }
    }
}
