package com.aura.lamplight.arcanum.test;

import com.aura.lamplight.arcanum.Arcanum;
import com.aura.lamplight.arcanum.enchantment.ArcanumEnchantments;
import com.aura.lamplight.arcanum.server.RebuildHandler;
import io.netty.channel.ChannelHandler;
import io.netty.channel.embedded.EmbeddedChannel;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.Holder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.arrow.AbstractArrow;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.ItemEnchantments;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.gamerules.GameRules;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.IntConsumer;
import java.util.function.Supplier;

/**
 * Headless enchantment test suite. Gated by the {@code lamplight.tests} system
 * property; run with {@code JAVA_TOOL_OPTIONS="-Dlamplight.tests=true" ./gradlew runServer}.
 * Builds a sky platform, spawns mock players, runs every {@link TestDef} in
 * order, prints a PASS/FAIL report and halts the server.
 */
public final class ArcanumTestRunner {
    private static final Logger LOGGER = LoggerFactory.getLogger("ArcanumTest");

    private static final int FLOOR_Y = 200; // stone layer; entities stand at y=201
    private static final int WARMUP_TICKS = 80;
    private static final int COOLDOWN_TICKS = 10;

    private enum Phase { WARMUP, RUNNING, VERIFY, COOLDOWN, DONE }

    private static MinecraftServer server;
    private static ServerLevel level;
    private static TestPlayer hero;   // attacker, at (0.5, 201, 0.5)
    private static TestPlayer ally;   // second player, at (0.5, 201, 2.5)
    private static List<TestDef> tests = List.of();
    private static int index = -1;
    private static Phase phase = Phase.DONE;
    private static int phaseTick = 0;
    private static final List<String> REPORT = new ArrayList<>();

    private ArcanumTestRunner() {}

    // ------------------------------------------------------------------
    // wiring
    // ------------------------------------------------------------------

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTED.register(ArcanumTestRunner::bootstrap);
        ServerTickEvents.END_SERVER_TICK.register(ArcanumTestRunner::tick);
    }

    /** One test: setup (once), tick(i) for {@code ticks} ticks, then verify (null = pass). */
    public record TestDef(String name, int ticks, Runnable setup, java.util.function.IntConsumer tick,
                          Supplier<String> verify) {}

    private static void bootstrap(MinecraftServer srv) {
        server = srv;
        level = srv.getLevel(Level.OVERWORLD);
        if (level == null) {
            LOGGER.error("[ARCANUM-TEST] no overworld; aborting");
            return;
        }
        // deterministic world: no regen (heals would corrupt HP asserts), no natural spawns
        level.getGameRules().set(GameRules.NATURAL_HEALTH_REGENERATION, false, server);
        level.getGameRules().set(GameRules.SPAWN_MOBS, false, server);
        level.getGameRules().set(GameRules.SPAWN_MONSTERS, false, server);
        level.getGameRules().set(GameRules.SPAWN_PATROLS, false, server);
        level.getGameRules().set(GameRules.SPAWN_PHANTOMS, false, server);
        buildPlatform();
        hero = createPlayer("test-hero");
        ally = createPlayer("test-ally");
        tests = ArcanumTests.build();
        phase = Phase.WARMUP;
        phaseTick = 0;
        LOGGER.info("[ARCANUM-TEST] suite started: {} tests, {} mock players", tests.size(), 2);
    }

    private static void buildPlatform() {
        for (int x = -12; x <= 12; x++) {
            for (int z = -12; z <= 12; z++) {
                level.setBlock(new BlockPos(x, FLOOR_Y, z), Blocks.STONE.defaultBlockState(), 3);
                for (int y = FLOOR_Y + 1; y <= FLOOR_Y + 7; y++) {
                    level.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
    }

    /** Vanilla's GameTestHelper#makeMockServerPlayerInLevel recipe, as a subclass so tests can force full attack charge. */
    public static class TestPlayer extends ServerPlayer {
        public TestPlayer(MinecraftServer srv, ServerLevel lvl, com.mojang.authlib.GameProfile profile) {
            super(srv, lvl, profile, ClientInformation.createDefault());
        }

        /** Pretend the attack cooldown has fully elapsed (attackStrengthTicker is protected on LivingEntity). */
        public void charge() {
            this.attackStrengthTicker = 1000;
        }
    }

    private static TestPlayer createPlayer(String name) {
        com.mojang.authlib.GameProfile profile = new com.mojang.authlib.GameProfile(UUID.randomUUID(), name);
        CommonListenerCookie cookie = CommonListenerCookie.createInitial(profile, false);
        Connection connection = new Connection(PacketFlow.SERVERBOUND);
        new EmbeddedChannel(new ChannelHandler[]{connection});
        TestPlayer player = new TestPlayer(server, level, profile);
        server.getPlayerList().placeNewPlayer(connection, player, cookie);
        return player;
    }

    // ------------------------------------------------------------------
    // state machine
    // ------------------------------------------------------------------

    private static void tick(MinecraftServer srv) {
        if (phase == Phase.DONE || server == null) return;
        phaseTick++;
        try {
            switch (phase) {
                case WARMUP -> {
                    if (phaseTick >= WARMUP_TICKS) beginTest();
                }
                case RUNNING -> {
                    TestDef def = tests.get(index);
                    if (phaseTick == 1) {
                        cleanup();
                        try {
                            def.setup().run();
                        } catch (Throwable t) {
                            record(def, "setup threw: " + t);
                            beginCooldown();
                            return;
                        }
                    }
                    try {
                        def.tick().accept(phaseTick - 1);
                    } catch (Throwable t) {
                        record(def, "tick " + (phaseTick - 1) + " threw: " + t);
                        beginCooldown();
                        return;
                    }
                    if (phaseTick >= def.ticks()) phase = Phase.VERIFY;
                }
                case VERIFY -> {
                    TestDef def = tests.get(index);
                    try {
                        record(def, def.verify().get());
                    } catch (Throwable t) {
                        record(def, "verify threw: " + t);
                    }
                    beginCooldown();
                }
                case COOLDOWN -> {
                    if (phaseTick >= COOLDOWN_TICKS) beginTest();
                }
                case DONE -> {}
            }
        } catch (Throwable t) {
            LOGGER.error("[ARCANUM-TEST] harness crashed, halting", t);
            finish();
        }
    }

    private static void beginTest() {
        index++;
        if (index >= tests.size()) {
            finish();
            return;
        }
        phase = Phase.RUNNING;
        phaseTick = 0;
    }

    private static void beginCooldown() {
        phase = Phase.COOLDOWN;
        phaseTick = 0;
    }

    private static void record(TestDef def, String err) {
        String line = err == null ? "PASS" : "FAIL: " + err;
        LOGGER.info("[ARCANUM-TEST] {} -> {}", def.name(), line);
        REPORT.add(def.name() + " :: " + line);
    }

    private static void finish() {
        long failed = REPORT.stream().filter(l -> l.contains("FAIL")).count();
        LOGGER.info("[ARCANUM-TEST] ========================================");
        for (String line : REPORT) LOGGER.info("[ARCANUM-TEST] {}", line);
        LOGGER.info("[ARCANUM-TEST] ========================================");
        LOGGER.info("[ARCANUM-TEST] SUMMARY: {} passed, {} failed, {} total",
                REPORT.size() - failed, failed, REPORT.size());
        phase = Phase.DONE;
        server.halt(false);
    }

    // ------------------------------------------------------------------
    // per-test hygiene
    // ------------------------------------------------------------------

    private static void cleanup() {
        for (Entity e : level.getAllEntities()) {
            if (!(e instanceof Player)) e.discard();
        }
        resetPlayer(hero, 0.5, 0.5);
        resetPlayer(ally, 0.5, 2.5);
        RebuildHandler.clearPlayer(hero.getUUID());
        RebuildHandler.clearPlayer(ally.getUUID());
        for (int x = -12; x <= 12; x++) {
            for (int z = -12; z <= 12; z++) {
                level.setBlock(new BlockPos(x, FLOOR_Y, z), Blocks.STONE.defaultBlockState(), 3);
                for (int y = FLOOR_Y + 1; y <= FLOOR_Y + 7; y++) {
                    level.setBlock(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
    }

    private static void resetPlayer(TestPlayer p, double x, double z) {
        p.removeAllEffects();
        p.getInventory().clearContent();
        p.setHealth(p.getMaxHealth());
        p.fallDistance = 0;
        p.invulnerableTime = 0;
        p.setNoGravity(false);
        p.setSprinting(false);
        p.setShiftKeyDown(false);
        p.stopUsingItem();
        p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
        p.setItemInHand(InteractionHand.OFF_HAND, ItemStack.EMPTY);
        p.absSnapTo(x, FLOOR_Y + 1, z, 0F, 0F);
    }

    // ------------------------------------------------------------------
    // test-building helpers (used by ArcanumTests)
    // ------------------------------------------------------------------

    public static MinecraftServer server() { return server; }
    public static ServerLevel level() { return level; }
    public static TestPlayer hero() { return hero; }
    public static TestPlayer ally() { return ally; }

    /** A copy of {@code base} carrying {@code key} at {@code lvl}. */
    public static ItemStack ench(Item base, ResourceKey<Enchantment> key, int lvl) {
        return ench(new ItemStack(base), key, lvl);
    }

    public static ItemStack ench(ItemStack base, ResourceKey<Enchantment> key, int lvl) {
        ItemStack out = base.copy();
        Holder<Enchantment> holder = server.registryAccess().lookupOrThrow(Registries.ENCHANTMENT).getOrThrow(key);
        ItemEnchantments.Mutable mut = new ItemEnchantments.Mutable(ItemEnchantments.EMPTY);
        mut.set(holder, lvl);
        out.set(DataComponents.ENCHANTMENTS, mut.toImmutable());
        return out;
    }

    public static void wearArmor(Player player, EquipmentSlot slot, Item piece, ResourceKey<Enchantment> key, int lvl) {
        player.setItemSlot(slot, ench(piece, key, lvl));
    }

    /** NoAI, fireproof (daylight burn would corrupt damage math), at floor level. */
    public static Zombie zombieAt(double x, double zCoord) {
        Zombie z = new Zombie(net.minecraft.world.entity.EntityTypes.ZOMBIE, level);
        z.setNoAi(true);
        z.snapTo(x, FLOOR_Y + 1, zCoord, 0F, 0F);
        z.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100000, 0, true, false, false));
        level.addFreshEntity(z);
        return z;
    }

    public static LivingEntity vindicatorAt(double x, double z) {
        var v = new net.minecraft.world.entity.monster.illager.Vindicator(
                net.minecraft.world.entity.EntityTypes.VINDICATOR, level);
        v.setNoAi(true);
        v.snapTo(x, FLOOR_Y + 1, z, 0F, 0F);
        v.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 100000, 0, true, false, false));
        level.addFreshEntity(v);
        return v;
    }

    /** Full-charge melee hit; returns the HP the victim lost. Throws if nothing connected. */
    public static float meleeLoss(TestPlayer attacker, ItemStack weapon, LivingEntity victim) {
        attacker.setItemInHand(InteractionHand.MAIN_HAND, weapon);
        attacker.charge();
        attacker.fallDistance = 0;
        float before = victim.getHealth();
        attacker.attack(victim);
        float loss = before - victim.getHealth();
        if (loss <= 0.01F) throw new IllegalStateException("attack did not connect");
        return loss;
    }

    /** Manually-propelled arrow (no bow draw needed); flies ~2 blocks/tick. */
    public static Arrow shootArrow(TestPlayer shooter, ItemStack weapon, double tx, double tz, double speed) {
        Arrow arrow = new Arrow(level, shooter, weapon, new ItemStack(Items.ARROW));
        double sx = shooter.getX(), sy = shooter.getY(1.7), sz = shooter.getZ();
        Vec3 dir = new Vec3(tx - sx, (FLOOR_Y + 2.0) - sy, tz - sz).normalize();
        arrow.snapTo(sx, sy, sz, 0F, 0F);
        arrow.setDeltaMovement(dir.scale(speed));
        arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
        level.addFreshEntity(arrow);
        return arrow;
    }

    /** Arrow aimed straight down at a floor block, for block-impact hooks. */
    public static Arrow shootArrowDown(TestPlayer shooter, ItemStack weapon, double x, double z) {
        Arrow arrow = new Arrow(level, shooter, weapon, new ItemStack(Items.ARROW));
        arrow.snapTo(x, FLOOR_Y + 1.6, z, 0F, 0F);
        arrow.setDeltaMovement(new Vec3(0, -0.4, 0));
        arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
        level.addFreshEntity(arrow);
        return arrow;
    }

    /** Sum of XP orb values within {@code r} of a point. */
    public static int xpNear(double x, double y, double z, double r) {
        int sum = 0;
        for (Entity e : level.getAllEntities()) {
            if (e instanceof ExperienceOrb orb && e.distanceToSqr(x, y, z) < r * r) sum += orb.getValue();
        }
        return sum;
    }

    /** Item entities of a specific item near a point. */
    public static boolean itemNear(double x, double y, double z, double r, Item item) {
        for (Entity e : level.getAllEntities()) {
            if (e instanceof ItemEntity it && it.distanceToSqr(x, y, z) < r * r
                    && it.getItem().is(item)) return true;
        }
        return false;
    }

    public static void discardItemsNear(double x, double y, double z, double r) {
        for (Entity e : level.getAllEntities()) {
            if (e instanceof ItemEntity it && it.distanceToSqr(x, y, z) < r * r) it.discard();
        }
    }

    public static void setBlock(int x, int y, int z, net.minecraft.world.level.block.state.BlockState state) {
        level.setBlock(new BlockPos(x, y, z), state, 3);
    }

    public static net.minecraft.world.level.block.state.BlockState block(int x, int y, int z) {
        return level.getBlockState(new BlockPos(x, y, z));
    }

    /** Kill a mob with the given weapon in the hero's main hand (keeps kill credit + weapon read). */
    public static void killWith(ItemStack weapon, LivingEntity victim) {
        hero.setItemInHand(InteractionHand.MAIN_HAND, weapon);
        victim.invulnerableTime = 0;
        victim.hurtServer(level, level.damageSources().playerAttack(hero), 1000.0F);
    }
}
