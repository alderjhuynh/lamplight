package com.aura.lamplight.arcanum.test;

import com.aura.lamplight.arcanum.Arcanum;
import com.aura.lamplight.arcanum.enchantment.ArcanumEnchantments;
import com.aura.lamplight.arcanum.server.RebuildHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.entity.projectile.arrow.Arrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ChargedProjectiles;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.function.IntConsumer;
import java.util.function.Supplier;

import static com.aura.lamplight.arcanum.test.ArcanumTestRunner.*;

/**
 * Every headless-testable Arcanum enchantment, one TestDef each.
 * Skipped (headless-impossible or RNG-fragile): feint/coyote/wall_kick/chain shot
 * flow (packet-driven), echo/plunder/gravedigger/tiller/bloom/gleaner odds,
 * verdant_pulse (needs real player movement), client-movement STRIDE enchantments.
 */
final class ArcanumTests {
    private ArcanumTests() {}

    static List<TestDef> build() {
        return List.of(
                // ---------------- EDGE (weapon melee) ----------------
                undertow(), severing(), rhythm(), rend(), vulture(), staticCharge(),
                whirlwind(), splinter(), reap(), bane(), spite(),
                // ---------------- TEMPO ----------------
                flurry(), firstBlood(), momentum(), heavyOneTap(), heavySmallFall(),
                riposte(), stormbrand(), phalanx(),
                // ---------------- kill riders ----------------
                siphon(), fanfare(), bulwark(), finale(), tuition(),
                // ---------------- RANGED (arrow flight takes ~2 ticks; reads happen on later ticks) ----------------
                tailwind(), deadeye(), knockshot(), heavyDraw(), markedQuarry(),
                smokeVeil(), singe(), steadyAim(), chainLoad(), kiting(),
                // ---------------- WARD / armor ----------------
                stormCoil(), kiln(), rampart(), lastStand(), gripSpikes(),
                stickyLanding(), lamplight(), adrenaline(), scentOfBlood(),
                deepGaze(), pilgrim(), magnetism(),
                // ---------------- STRIDE ----------------
                cometfall(),
                // ---------------- METHOD / BOON tools ----------------
                feller(), trencher(), replanter(), kilnHands()
        );
    }

    private static TestDef test(String name, Runnable setup, Supplier<String> verify) {
        return new TestDef(name, 1, setup, t -> {}, verify);
    }

    private static TestDef timed(String name, int ticks, Runnable setup,
                                 IntConsumer tick, Supplier<String> verify) {
        return new TestDef(name, ticks, setup, tick, verify);
    }

    private static void heal(LivingEntity e) {
        e.setHealth(e.getMaxHealth());
        e.invulnerableTime = 0;
    }

    // ------------------------------------------------------------------
    // EDGE
    // ------------------------------------------------------------------

    private static TestDef undertow() {
        return test("undertow", () -> {}, () -> {
            Zombie cz = zombieAt(2.5, 0.5);
            meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            double dotC = towardHeroDot(cz);
            cz.discard();

            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.UNDERTOW, 1);
            Zombie ez = zombieAt(2.5, 0.5);
            meleeLoss(hero(), weapon, ez);
            double dotE = towardHeroDot(ez);

            // vanilla knockback pushes away; Undertow drags toward the attacker
            if (dotC >= 0) return "control knockback should push away (dot " + dotC + ")";
            if (dotE <= dotC + 0.2) return "undertow did not drag toward hero (dot " + dotE + " vs " + dotC + ")";
            return null;
        });
    }

    private static double towardHeroDot(Entity e) {
        Vec3 delta = e.getDeltaMovement();
        if (delta.horizontalDistanceSqr() < 1e-6) return 0;
        Vec3 toHero = new Vec3(hero().getX() - e.getX(), 0, hero().getZ() - e.getZ()).normalize();
        return delta.multiply(1, 0, 1).normalize().dot(toHero);
    }

    private static TestDef severing() {
        return test("severing", () -> {}, () -> {
            Zombie cz = zombieAt(2.5, 0.5);
            cz.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
            float lossC = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            cz.discard();

            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.SEVERING, 2);
            Zombie ez = zombieAt(2.5, 0.5);
            ez.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
            float lossE = meleeLoss(hero(), weapon, ez);
            if (lossE <= lossC + 0.15F) return "armored hit not shredded: " + lossE + " vs control " + lossC;
            return null;
        });
    }

    private static TestDef rhythm() {
        return test("rhythm", () -> {}, () -> {
            Zombie cz = zombieAt(2.5, 0.5);
            float lossC = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            cz.discard();

            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.RHYTHM, 1);
            Zombie ez = zombieAt(2.5, 0.5);
            float lossE = meleeLoss(hero(), weapon, ez);
            if (lossE <= lossC + 0.6F) return "no charged-hit bonus: " + lossE + " vs " + lossC;
            return null;
        });
    }

    private static TestDef rend() {
        return timed("rend", 60, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.REND, 1);
            rendZ = zombieAt(2.5, 0.5);
            meleeLoss(hero(), weapon, rendZ);
            REND_BASELINE[0] = rendZ.getHealth();
        }, t -> {}, () -> {
            if (rendZ == null || !rendZ.isAlive()) return "victim died";
            // bleed: 1 dmg at ~40 ticks after the hit
            if (rendZ.getHealth() >= REND_BASELINE[0] - 0.3F)
                return "no bleed damage over 60 ticks (hp " + rendZ.getHealth() + ", baseline " + REND_BASELINE[0] + ")";
            return null;
        });
    }

    private static final float[] REND_BASELINE = {0};
    private static Zombie rendZ;

    private static TestDef vulture() {
        return test("vulture", () -> {}, () -> {
            Zombie cz = zombieAt(2.5, 0.5);
            float lossC = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            cz.discard();

            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.VULTURE, 1);
            Zombie ez = zombieAt(2.5, 0.5);
            ez.setHealth(8.0F); // below 50%
            float lossE = meleeLoss(hero(), weapon, ez);
            if (lossE <= lossC + 0.7F) return "no low-HP victim bonus: " + lossE + " vs " + lossC;
            return null;
        });
    }

    private static TestDef staticCharge() {
        return test("static_charge", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.STATIC_CHARGE, 1);
            Zombie z = zombieAt(2.5, 0.5);
            float l1 = meleeLoss(hero(), weapon, z);
            heal(z);
            meleeLoss(hero(), weapon, z);
            heal(z);
            float l3 = meleeLoss(hero(), weapon, z);
            if (l3 <= l1 + 3.0F) return "no 3rd-hit lightning bonus (l3 " + l3 + " vs l1 " + l1 + ")";
            return null;
        });
    }

    private static TestDef whirlwind() {
        return test("whirlwind", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.WHIRLWIND, 1);
            Zombie za = zombieAt(2.5, 0.5);
            Zombie zb = zombieAt(3.3, 0.5);
            meleeLoss(hero(), weapon, za);
            // a vanilla sweep (standing, charged, sword) should have hit and shoved zb
            boolean hurt = zb.getHealth() < 19.5F;
            boolean shoved = zb.getDeltaMovement().x > 0.1;
            if (!hurt && !shoved) return "sweep did not affect adjacent zombie";
            return null;
        });
    }

    private static TestDef splinter() {
        return test("splinter", () -> {}, () -> {
            TestPlayer blocker = ally();
            blocker.setItemInHand(InteractionHand.OFF_HAND, new ItemStack(Items.SHIELD));
            blocker.absSnapTo(0.5, 201, 2.5, 0F, 0F); // faces +z, hero attacks from behind
            blocker.startUsingItem(InteractionHand.OFF_HAND);
            if (!blocker.isBlocking()) return "ally did not enter blocking state";

            ItemStack axe = ench(Items.IRON_AXE, ArcanumEnchantments.SPLINTER, 1);
            meleeLoss(hero(), axe, blocker);

            if (blocker.isBlocking()) return "shield was not knocked down";
            if (!blocker.getCooldowns().isOnCooldown(new ItemStack(Items.SHIELD))) return "no shield cooldown";
            AttributeInstance move = blocker.getAttribute(Attributes.MOVEMENT_SPEED);
            if (move == null || !move.hasModifier(Arcanum.id("splinter_freeze"))) return "no movement freeze modifier";
            return null;
        });
    }

    private static TestDef reap() {
        return test("reap", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.REAP, 1);
            Zombie zf = zombieAt(2.5, 0.5);
            Zombie zb = zombieAt(3.6, 0.5);
            meleeLoss(hero(), weapon, zf);
            if (zb.getHealth() >= 19.5F) return "no cleave damage on target behind (hp " + zb.getHealth() + ")";
            return null;
        });
    }

    private static TestDef bane() {
        return test("bane_of_illagers", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.BANE_OF_ILLAGERS, 1);
            Zombie cz = zombieAt(2.5, 0.5);
            float lossC = meleeLoss(hero(), weapon, cz);
            cz.discard();

            LivingEntity v = vindicatorAt(2.5, 0.5);
            float lossV = meleeLoss(hero(), weapon, v);
            if (lossV <= lossC + 0.5F) return "no illager bonus (vindicator " + lossV + " vs zombie " + lossC + ")";
            return null;
        });
    }

    private static TestDef spite() {
        return test("spite", () -> {}, () -> {
            hero().setHealth(8.0F); // attacker below 50%
            Zombie cz = zombieAt(2.5, 0.5);
            float lossC = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            cz.discard();

            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.SPITE, 1);
            Zombie ez = zombieAt(2.5, 0.5);
            float lossE = meleeLoss(hero(), weapon, ez);
            if (lossE <= lossC + 1.0F) return "no low-HP attacker bonus: " + lossE + " vs " + lossC;
            return null;
        });
    }

    // ------------------------------------------------------------------
    // TEMPO
    // ------------------------------------------------------------------

    private static TestDef flurry() {
        return timed("flurry", 8, () -> {}, t -> {
            if (t == 0) {
                ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.FLURRY, 1);
                flurryZ = zombieAt(2.5, 0.5);
                meleeLoss(hero(), weapon, flurryZ);
                heal(flurryZ);
                meleeLoss(hero(), weapon, flurryZ); // two hits within 2s -> activate
            }
            if (t == 5) {
                AttributeInstance speed = hero().getAttribute(Attributes.ATTACK_SPEED);
                FLURRY_MOD[0] = speed != null && speed.hasModifier(Arcanum.id("flurry_attack_speed"));
            }
        }, () -> {
            if (!FLURRY_MOD[0]) return "no attack speed modifier after two quick hits";
            return null;
        });
    }

    private static final boolean[] FLURRY_MOD = {false};
    private static Zombie flurryZ;

    private static TestDef firstBlood() {
        return test("first_blood", () -> {}, () -> {
            Zombie cz = zombieAt(2.5, 0.5);
            float lossC = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            cz.discard();

            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.FIRST_BLOOD, 1);
            Zombie ez = zombieAt(2.5, 0.5);
            float lossE = meleeLoss(hero(), weapon, ez);
            if (lossE <= lossC + 2.2F) return "no opening-hit bonus: " + lossE + " vs " + lossC;
            return null;
        });
    }

    private static TestDef momentum() {
        return test("momentum", () -> {}, () -> {
            hero().setSprinting(true);
            Zombie cz = zombieAt(2.5, 0.5);
            meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            double pushC = cz.getDeltaMovement().horizontalDistance();
            cz.discard();

            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.MOMENTUM, 2);
            hero().setSprinting(true);
            Zombie ez = zombieAt(2.5, 0.5);
            meleeLoss(hero(), weapon, ez);
            double pushE = ez.getDeltaMovement().horizontalDistance();
            if (pushE <= pushC + 0.3) return "sprint knockback not boosted: " + pushE + " vs " + pushC;
            return null;
        });
    }

    private static TestDef heavyOneTap() {
        return test("heavy_one_tap_200_fall", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.HEAVY, 1);
            Zombie z = zombieAt(2.5, 0.5);
            hero().setItemInHand(InteractionHand.MAIN_HAND, weapon);
            hero().charge();
            hero().fallDistance = 200.0; // half the vanilla mace curve -> ~+107
            hero().attack(z);
            hero().fallDistance = 0;
            if (z.isAlive()) return "zombie survived a 200-block-fall Heavy hit (hp " + z.getHealth() + ")";
            return null;
        });
    }

    private static TestDef heavySmallFall() {
        return test("heavy_small_fall", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.HEAVY, 1);
            Zombie cz = zombieAt(2.5, 0.5);
            float lossC = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            cz.discard();

            Zombie ez = zombieAt(2.5, 0.5);
            hero().setItemInHand(InteractionHand.MAIN_HAND, weapon);
            hero().charge();
            hero().fallDistance = 1.0; // 1 block drop -> +2
            hero().attack(ez);
            hero().fallDistance = 0;
            float lossE = 20.0F - ez.getHealth();
            if (lossE <= lossC + 1.5F) return "1-block fall bonus missing: " + lossE + " vs " + lossC;
            if (!ez.hasEffect(MobEffects.SLOWNESS)) return "no slowness applied";
            return null;
        });
    }

    private static TestDef riposte() {
        return test("riposte", () -> {}, () -> {
            Zombie z = zombieAt(2.5, 0.5);
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.RIPOSTE, 1);
            float lossC = meleeLoss(hero(), weapon, z); // no window armed yet
            heal(z);

            hero().invulnerableTime = 0;
            hero().hurtServer(level(), level().damageSources().mobAttack(z), 2.0F); // arms the 2s window
            float lossE = meleeLoss(hero(), weapon, z);
            if (lossE <= lossC + 1.2F) return "no riposte bonus: " + lossE + " vs " + lossC;
            return null;
        });
    }

    private static TestDef stormbrand() {
        return test("stormbrand", () -> {}, () -> {
            Zombie cz = zombieAt(2.5, 0.5);
            float lossC = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), cz);
            cz.discard();

            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.STORMBRAND, 1);
            setBlock(0, 201, 0, Blocks.WATER.defaultBlockState()); // hero stands in water
            Zombie ez = zombieAt(2.5, 0.5);
            float lossE = meleeLoss(hero(), weapon, ez);
            if (lossE <= lossC + 1.2F) return "no wet bonus: " + lossE + " vs " + lossC;
            return null;
        });
    }

    private static TestDef phalanx() {
        return test("phalanx", () -> {}, () -> {
            ally().absSnapTo(0.5, 201, 20.5, 0F, 0F); // far away: control
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.PHALANX, 1);
            Zombie cz = zombieAt(2.5, 0.5);
            float lossC = meleeLoss(hero(), weapon, cz);
            cz.discard();

            ally().absSnapTo(0.5, 201, 2.5, 0F, 0F); // ally nearby
            Zombie ez = zombieAt(2.5, 0.5);
            float lossE = meleeLoss(hero(), weapon, ez);
            if (lossE <= lossC + 0.5F) return "no ally bonus: " + lossE + " vs " + lossC;
            return null;
        });
    }

    // ------------------------------------------------------------------
    // kill riders
    // ------------------------------------------------------------------

    private static TestDef siphon() {
        return test("siphon", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.SIPHON, 1);
            Zombie z = zombieAt(2.5, 0.5);
            hero().setHealth(10.0F);
            killWith(weapon, z);
            if (hero().getHealth() <= 10.4F) return "no heal on kill (hp " + hero().getHealth() + ")";
            return null;
        });
    }

    private static TestDef fanfare() {
        return test("fanfare", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.FANFARE, 1);
            Zombie z = zombieAt(2.5, 0.5);
            killWith(weapon, z);
            if (!hero().hasEffect(MobEffects.SPEED)) return "no speed effect on kill";
            return null;
        });
    }

    private static TestDef bulwark() {
        return test("bulwark", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.BULWARK, 1);
            Zombie z = zombieAt(2.5, 0.5);
            killWith(weapon, z);
            if (!hero().hasEffect(MobEffects.RESISTANCE)) return "no resistance effect on kill";
            return null;
        });
    }

    private static TestDef finale() {
        return test("finale", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.FINALE, 1);
            Zombie z = zombieAt(2.5, 0.5);
            Zombie neighbor = zombieAt(3.5, 0.5);
            killWith(weapon, z);
            if (neighbor.getRemainingFireTicks() <= 0) return "neighbor not ignited by finale kill";
            return null;
        });
    }

    private static TestDef tuition() {
        return test("tuition", () -> {}, () -> {
            ItemStack weapon = ench(Items.IRON_SWORD, ArcanumEnchantments.TUITION, 1);
            Zombie z = zombieAt(2.5, 0.5);
            killWith(weapon, z);
            int xp = xpNear(2.5, 201, 0.5, 6.0);
            // zombie base xp = 5; Tuition I = *1.15 -> 5.75 -> round 6
            if (xp < 6) return "xp not boosted (got " + xp + ", expected >= 6)";
            if (xp > 8) return "xp implausibly large: " + xp;
            return null;
        });
    }

    // ------------------------------------------------------------------
    // RANGED
    // ------------------------------------------------------------------

    private static TestDef tailwind() {
        return timed("tailwind", 12, () -> {
            hero().setNoGravity(true);
            hero().absSnapTo(0.5, 202.0, 0.5, 0F, 0F); // suspended mid-air
            tailwindZ = zombieAt(4.5, 0.5);
            shootArrow(hero(), ench(Items.BOW, ArcanumEnchantments.TAILWIND, 1), 4.5, 0.5, 2.5);
        }, t -> {
            if (t == 4) {
                TAILWIND_E[0] = 20.0F - tailwindZ.getHealth();
                tailwindZ.discard();
                hero().setNoGravity(false);
                hero().absSnapTo(0.5, 201, 0.5, 0F, 0F);
                tailwindZ = zombieAt(4.5, 0.5);
                shootArrow(hero(), new ItemStack(Items.BOW), 4.5, 0.5, 2.5);
            }
            if (t == 10) TAILWIND_C[0] = 20.0F - tailwindZ.getHealth();
        }, () -> {
            if (TAILWIND_E[0] <= 0 || TAILWIND_C[0] <= 0)
                return "arrow did not connect (E " + TAILWIND_E[0] + ", C " + TAILWIND_C[0] + ")";
            if (TAILWIND_E[0] <= TAILWIND_C[0] + 0.15F) return "no airborne arrow bonus: " + TAILWIND_E[0] + " vs " + TAILWIND_C[0];
            return null;
        });
    }

    private static final float[] TAILWIND_E = {0}, TAILWIND_C = {0};
    private static Zombie tailwindZ;

    private static TestDef deadeye() {
        return timed("deadeye", 14, () -> {
            deadeyeZ = zombieAt(4.5, 0.5);
            shootArrow(hero(), ench(Items.BOW, ArcanumEnchantments.DEADEYE, 1), 4.5, 0.5, 2.5);
        }, t -> {
            if (t == 4) {
                DEADEYE_FIRST[0] = 20.0F - deadeyeZ.getHealth();
                heal(deadeyeZ);
                shootArrow(hero(), ench(Items.BOW, ArcanumEnchantments.DEADEYE, 1), 4.5, 0.5, 2.5);
            }
            if (t == 10) DEADEYE_SECOND[0] = 20.0F - deadeyeZ.getHealth();
        }, () -> {
            if (DEADEYE_SECOND[0] <= 0.01F) return "second arrow did not connect";
            if (DEADEYE_FIRST[0] <= DEADEYE_SECOND[0] + 0.5F)
                return "no first-shot bonus (first " + DEADEYE_FIRST[0] + " vs second " + DEADEYE_SECOND[0] + ")";
            return null;
        });
    }

    private static final float[] DEADEYE_FIRST = {0}, DEADEYE_SECOND = {0};
    private static Zombie deadeyeZ;

    private static TestDef knockshot() {
        return timed("knockshot", 10, () -> {
            zombieAt(4.5, 0.5);
            knockZ2 = zombieAt(4.5, 2.7);
            shootArrow(hero(), ench(Items.BOW, ArcanumEnchantments.KNOCKSHOT, 1), 4.5, 0.5, 2.5);
        }, t -> {}, () -> {
            if (knockZ2 == null || !knockZ2.isAlive()) return "neighbor zombie gone";
            if (knockZ2.getZ() <= 2.9) return "adjacent zombie not blasted away (z " + knockZ2.getZ() + ")";
            return null;
        });
    }

    private static Zombie knockZ2;

    private static TestDef heavyDraw() {
        return timed("heavy_draw", 14, () -> {
            heavyDrawZ = zombieAt(4.5, 0.5);
            shootArrow(hero(), ench(Items.BOW, ArcanumEnchantments.HEAVY_DRAW, 2), 4.5, 0.5, 2.5);
        }, t -> {
            if (t == 4) {
                HEAVYDRAW_C[0] = 20.0F - heavyDrawZ.getHealth();
                heal(heavyDrawZ);
                Arrow crit = shootArrow(hero(), ench(Items.BOW, ArcanumEnchantments.HEAVY_DRAW, 2), 4.5, 0.5, 2.5);
                crit.setCritArrow(true);
            }
            if (t == 10) HEAVYDRAW_E[0] = 20.0F - heavyDrawZ.getHealth();
        }, () -> {
            if (HEAVYDRAW_E[0] <= 0.01F) return "crit arrow did not connect";
            if (HEAVYDRAW_E[0] <= HEAVYDRAW_C[0] + 2.5F) return "no crit bonus: " + HEAVYDRAW_E[0] + " vs " + HEAVYDRAW_C[0];
            return null;
        });
    }

    private static final float[] HEAVYDRAW_C = {0}, HEAVYDRAW_E = {0};
    private static Zombie heavyDrawZ;

    private static TestDef markedQuarry() {
        return timed("marked_quarry", 14, () -> {
            markedZ = zombieAt(4.5, 0.5);
            shootArrow(hero(), ench(Items.BOW, ArcanumEnchantments.MARKED_QUARRY, 1), 4.5, 0.5, 2.5);
        }, t -> {
            if (t == 5) {
                heal(markedZ);
                MARKED_MELEE[0] = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), markedZ);
            }
        }, () -> {
            // plain charged melee on a fresh zombie is ~5.5; a mark adds +10%
            if (MARKED_MELEE[0] <= 5.8F) return "marked victim did not take +10% (melee loss " + MARKED_MELEE[0] + ")";
            return null;
        });
    }

    private static final float[] MARKED_MELEE = {0};
    private static Zombie markedZ;

    private static TestDef smokeVeil() {
        return timed("smoke_veil", 10, () -> {
            shootArrowDown(hero(), ench(Items.BOW, ArcanumEnchantments.SMOKE_VEIL, 1), 2.5, 0.5);
        }, t -> {
            if (t >= 4 && !SMOKE_FOUND[0]) {
                for (Entity e : level().getAllEntities()) {
                    if (e instanceof AreaEffectCloud && e.distanceToSqr(2.5, 201, 0.5) < 16.0) SMOKE_FOUND[0] = true;
                }
            }
        }, () -> {
            if (!SMOKE_FOUND[0]) return "no smoke cloud spawned at arrow impact";
            return null;
        });
    }

    private static final boolean[] SMOKE_FOUND = {false};

    private static TestDef singe() {
        return timed("singe", 55, () -> {
            shootArrowDown(hero(), ench(Items.BOW, ArcanumEnchantments.SINGE, 1), 4.5, 0.5);
        }, t -> {
            if (t == 5) SINGE_FIRE_SEEN[0] = block(4, 202, 0).is(Blocks.FIRE);
            if (t == 50) SINGE_CLEANED[0] = block(4, 202, 0).isAir();
        }, () -> {
            if (!SINGE_FIRE_SEEN[0]) return "singe fire never appeared above impact";
            if (!SINGE_CLEANED[0]) return "singe fire not cleaned up after 2s (block " + block(4, 202, 0) + ")";
            return null;
        });
    }

    private static final boolean[] SINGE_FIRE_SEEN = {false}, SINGE_CLEANED = {false};

    private static TestDef steadyAim() {
        return test("steady_aim", () -> {}, () -> {
            ItemStack plain = new ItemStack(Items.BOW);
            ItemStack steady = ench(Items.BOW, ArcanumEnchantments.STEADY_AIM, 1);
            Arrow a1 = new Arrow(level(), hero(), plain, new ItemStack(Items.ARROW));
            a1.snapTo(10, 201.6, 10, 0F, 0F);
            a1.setDeltaMovement(new Vec3(1, 0, 0));
            Arrow a2 = new Arrow(level(), hero(), steady, new ItemStack(Items.ARROW));
            a2.snapTo(12, 201.6, 10, 0F, 0F);
            a2.setDeltaMovement(new Vec3(1, 0, 0));
            RebuildHandler.onArrowLaunch(level(), a1);
            RebuildHandler.onArrowLaunch(level(), a2);
            double l1 = a1.getDeltaMovement().horizontalDistance();
            double l2 = a2.getDeltaMovement().horizontalDistance();
            if (Math.abs(l2 - l1 * 1.2) > 0.02) return "launch speed not boosted 20% (" + l2 + " vs " + l1 + ")";
            return null;
        });
    }

    private static TestDef chainLoad() {
        return test("chain_load", () -> {}, () -> {
            ItemStack cb = ench(Items.CROSSBOW, ArcanumEnchantments.CHAIN_LOAD, 1);
            cb.set(DataComponents.CHARGED_PROJECTILES, ChargedProjectiles.of(new ItemStackTemplate(Items.ARROW)));
            if (!CrossbowItem.isCharged(cb)) return "crossbow did not start charged";

            // first release: the shot clears projectiles, Chain Load re-arms them
            RebuildHandler.onCrossbowReleaseHead(hero(), cb);
            cb.set(DataComponents.CHARGED_PROJECTILES, ChargedProjectiles.EMPTY);
            RebuildHandler.onCrossbowReleaseTail(hero(), cb);
            if (!CrossbowItem.isCharged(cb)) return "first shot was not re-armed by Chain Load";

            // second release: cycle is spent, must recharge
            RebuildHandler.onCrossbowReleaseHead(hero(), cb);
            cb.set(DataComponents.CHARGED_PROJECTILES, ChargedProjectiles.EMPTY);
            RebuildHandler.onCrossbowReleaseTail(hero(), cb);
            if (CrossbowItem.isCharged(cb)) return "second shot was wrongly re-armed";
            return null;
        });
    }

    private static TestDef kiting() {
        return timed("kiting", 10, () -> {
            hero().setItemInHand(InteractionHand.MAIN_HAND, ench(Items.CROSSBOW, ArcanumEnchantments.KITING, 1));
            hero().startUsingItem(InteractionHand.MAIN_HAND); // charging the crossbow
        }, t -> {
            if (t == 3) {
                AttributeInstance move = hero().getAttribute(Attributes.MOVEMENT_SPEED);
                KITING_ON[0] = move != null && move.hasModifier(Arcanum.id("kiting_charge"));
                hero().stopUsingItem();
            }
            if (t == 7) {
                AttributeInstance move = hero().getAttribute(Attributes.MOVEMENT_SPEED);
                KITING_OFF[0] = move == null || !move.hasModifier(Arcanum.id("kiting_charge"));
            }
        }, () -> {
            if (!KITING_ON[0]) return "no +50% move speed while charging";
            if (!KITING_OFF[0]) return "speed modifier not removed after charging";
            return null;
        });
    }

    private static final boolean[] KITING_ON = {false}, KITING_OFF = {false};

    // ------------------------------------------------------------------
    // WARD / armor (control-vs-enchanted comparisons, robust to vanilla armor math)
    // ------------------------------------------------------------------

    private static TestDef stormCoil() {
        return timed("storm_coil", 10, () -> {
            wearArmor(hero(), EquipmentSlot.CHEST, Items.IRON_CHESTPLATE, ArcanumEnchantments.STORM_COIL, 1);
            coilSrc = zombieAt(10.5, 10.5); // damage-source stand-in, out of the way
        }, t -> {
            if (t <= 3) { // four hits taken -> one charge stored
                hero().invulnerableTime = 0;
                hero().setHealth(20.0F);
                hero().hurtServer(level(), level().damageSources().mobAttack(coilSrc), 2.0F);
            }
        }, () -> {
            Zombie z = zombieAt(2.5, 0.5);
            float loss = meleeLoss(hero(), new ItemStack(Items.IRON_SWORD), z);
            if (loss <= 6.3F) return "stored charge not spent on hit (loss " + loss + ", want ~7.0)";
            return null;
        });
    }

    private static Zombie coilSrc;

    private static TestDef kiln() {
        return timed("kiln", 6, () -> {
            hero().setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET)); // plain: control
            hero().igniteForSeconds(5.0F);
            kilnZ = zombieAt(10.5, 10.5);
        }, t -> {
            if (t == 1) { // control fire hit while wearing the plain helmet
                hero().invulnerableTime = 0;
                float before = hero().getHealth();
                hero().hurtServer(level(), level().damageSources().onFire(), 4.0F);
                KILN_C[0] = before - hero().getHealth();
                heal(hero());
                wearArmor(hero(), EquipmentSlot.HEAD, Items.IRON_HELMET, ArcanumEnchantments.KILN, 1);
            }
            if (t == 4) {
                AttributeInstance attack = hero().getAttribute(Attributes.ATTACK_DAMAGE);
                KILN_MOD[0] = attack != null && attack.hasModifier(Arcanum.id("kiln_burning"));
            }
        }, () -> {
            if (!KILN_MOD[0]) return "no burning strength modifier";
            hero().invulnerableTime = 0;
            float before = hero().getHealth();
            hero().hurtServer(level(), level().damageSources().onFire(), 4.0F);
            float lossE = before - hero().getHealth();
            if (lossE > KILN_C[0] * 0.75F + 0.12F || lossE < KILN_C[0] * 0.75F - 0.12F)
                return "fire damage not reduced 25% (" + lossE + " vs control " + KILN_C[0] + ")";
            return null;
        });
    }

    private static final float[] KILN_C = {0};
    private static final boolean[] KILN_MOD = {false};
    private static Zombie kilnZ;

    private static TestDef rampart() {
        return timed("rampart", 55, () -> {
            wearArmor(hero(), EquipmentSlot.FEET, Items.IRON_BOOTS, ArcanumEnchantments.RAMPART, 1);
            rampartZ = zombieAt(10.5, 10.5);
        }, t -> {
            if (t == 5) { // not yet still for 2s: control hit
                hero().invulnerableTime = 0;
                float before = hero().getHealth();
                hero().hurtServer(level(), level().damageSources().generic(), 5.0F);
                RAMPART_C[0] = before - hero().getHealth();
                heal(hero());
            }
        }, () -> {
            hero().invulnerableTime = 0;
            float before = hero().getHealth();
            hero().hurtServer(level(), level().damageSources().generic(), 5.0F);
            float lossE = before - hero().getHealth();
            if (lossE > RAMPART_C[0] * 0.96F + 0.1F || lossE < RAMPART_C[0] * 0.96F - 0.1F)
                return "stillness resistance missing (" + lossE + " vs control " + RAMPART_C[0] + ")";
            return null;
        });
    }

    private static final float[] RAMPART_C = {0};
    private static Zombie rampartZ;

    private static TestDef lastStand() {
        return timed("last_stand", 6, () -> {
            wearArmor(hero(), EquipmentSlot.CHEST, Items.IRON_CHESTPLATE, ArcanumEnchantments.LAST_STAND, 1);
            lastStandZ = zombieAt(10.5, 10.5);
        }, t -> {
            if (t == 1) { // control: full health
                hero().invulnerableTime = 0;
                float before = hero().getHealth();
                hero().hurtServer(level(), level().damageSources().generic(), 5.0F);
                LASTSTAND_C[0] = before - hero().getHealth();
                heal(hero());
                hero().setHealth(7.0F); // below 40%
            }
            if (t == 4) {
                AttributeInstance move = hero().getAttribute(Attributes.MOVEMENT_SPEED);
                LASTSTAND_SLOW[0] = move != null && move.hasModifier(Arcanum.id("last_stand_slow"));
            }
        }, () -> {
            hero().invulnerableTime = 0;
            float before = hero().getHealth();
            hero().hurtServer(level(), level().damageSources().generic(), 5.0F);
            float lossE = before - hero().getHealth();
            if (lossE > LASTSTAND_C[0] * 0.92F + 0.1F || lossE < LASTSTAND_C[0] * 0.92F - 0.1F)
                return "no 8% reduction below 40% HP (" + lossE + " vs control " + LASTSTAND_C[0] + ")";
            if (!LASTSTAND_SLOW[0]) return "no -10% speed price";
            return null;
        });
    }

    private static final float[] LASTSTAND_C = {0};
    private static final boolean[] LASTSTAND_SLOW = {false};
    private static Zombie lastStandZ;

    private static TestDef gripSpikes() {
        return timed("grip_spikes", 5, () -> {
            hero().setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS)); // plain: control
            gripZ = zombieAt(10.5, 10.5);
        }, t -> {
            if (t == 1) {
                hero().invulnerableTime = 0;
                float before = hero().getHealth();
                hero().hurtServer(level(), level().damageSources().fall(), 3.0F);
                GRIP_C[0] = before - hero().getHealth();
                heal(hero());
                wearArmor(hero(), EquipmentSlot.FEET, Items.IRON_BOOTS, ArcanumEnchantments.GRIP_SPIKES, 1);
            }
        }, () -> {
            hero().invulnerableTime = 0;
            float before = hero().getHealth();
            hero().hurtServer(level(), level().damageSources().fall(), 3.0F);
            float lossE = before - hero().getHealth();
            if (Math.abs(lossE - (GRIP_C[0] - 1.0F)) > 0.2F)
                return "fall damage not reduced by 1 (" + lossE + " vs control " + GRIP_C[0] + ")";
            return null;
        });
    }

    private static final float[] GRIP_C = {0};
    private static Zombie gripZ;

    private static TestDef stickyLanding() {
        return timed("sticky_landing", 10, () -> {
            wearArmor(hero(), EquipmentSlot.FEET, Items.IRON_BOOTS, ArcanumEnchantments.STICKY_LANDING, 1);
        }, t -> {
            if (t == 3) {
                hero().invulnerableTime = 0;
                float before = hero().getHealth();
                hero().hurtServer(level(), level().damageSources().fall(), 3.0F);
                STICKY_NEGATED[0] = (before - hero().getHealth()) < 0.01F;
                hero().fallDistance = 2.0; // a real landing should pop you back up
            }
            if (t >= 5 && t <= 8 && hero().getDeltaMovement().y > 0.25) STICKY_BOUNCED[0] = true;
        }, () -> {
            if (!STICKY_NEGATED[0]) return "small fall damage not negated";
            if (!STICKY_BOUNCED[0]) return "no bouncy landing (deltaY " + hero().getDeltaMovement().y + ")";
            return null;
        });
    }

    private static final boolean[] STICKY_NEGATED = {false}, STICKY_BOUNCED = {false};

    private static TestDef lamplight() {
        return timed("lamplight", 5, () -> {
            wearArmor(hero(), EquipmentSlot.HEAD, Items.IRON_HELMET, ArcanumEnchantments.LAMPLIGHT, 1);
            hero().addEffect(new MobEffectInstance(MobEffects.DARKNESS, 200, 0, false, false, false));
        }, t -> {
            if (t == 4) {
                LAMP_CLEAN[0] = !hero().hasEffect(MobEffects.DARKNESS);
                LAMP_NV[0] = hero().hasEffect(MobEffects.NIGHT_VISION);
            }
        }, () -> {
            if (!LAMP_CLEAN[0]) return "darkness not cleansed";
            if (!LAMP_NV[0]) return "no interpretive night sight in the dark";
            return null;
        });
    }

    private static final boolean[] LAMP_CLEAN = {false}, LAMP_NV = {false};

    private static TestDef adrenaline() {
        return timed("adrenaline", 5, () -> {
            wearArmor(hero(), EquipmentSlot.CHEST, Items.IRON_CHESTPLATE, ArcanumEnchantments.ADRENALINE, 1);
            hero().setHealth(9.0F);
        }, t -> {
            if (t == 4) ADRENALINE_SPEED[0] = hero().hasEffect(MobEffects.SPEED);
        }, () -> {
            if (!ADRENALINE_SPEED[0]) return "no speed on crossing below 50% HP";
            return null;
        });
    }

    private static final boolean[] ADRENALINE_SPEED = {false};

    private static TestDef scentOfBlood() {
        return timed("scent_of_blood", 30, () -> {
            wearArmor(hero(), EquipmentSlot.CHEST, Items.IRON_CHESTPLATE, ArcanumEnchantments.SCENT_OF_BLOOD, 1);
            scentZ = zombieAt(3.5, 0.5);
            scentZ.setHealth(4.0F); // below 30%
        }, t -> {
            if (t >= 25) SCENT_GLOW[0] = scentZ.hasEffect(MobEffects.GLOWING);
        }, () -> {
            if (!SCENT_GLOW[0]) return "wounded hostile not glowing";
            return null;
        });
    }

    private static final boolean[] SCENT_GLOW = {false};
    private static Zombie scentZ;

    private static TestDef deepGaze() {
        return timed("deep_gaze", 5, () -> {
            wearArmor(hero(), EquipmentSlot.HEAD, Items.IRON_HELMET, ArcanumEnchantments.DEEP_GAZE, 1);
            setBlock(0, 202, 0, Blocks.WATER.defaultBlockState()); // hero's eyes submerged
        }, t -> {
            if (t == 4) DEEPGAZE_NV[0] = hero().hasEffect(MobEffects.NIGHT_VISION);
        }, () -> {
            if (!DEEPGAZE_NV[0]) return "no underwater night sight";
            return null;
        });
    }

    private static final boolean[] DEEPGAZE_NV = {false};

    private static TestDef pilgrim() {
        return timed("pilgrim", 5, () -> {
            wearArmor(hero(), EquipmentSlot.LEGS, Items.IRON_LEGGINGS, ArcanumEnchantments.PILGRIM, 1);
            setBlock(0, 200, 0, Blocks.DIRT_PATH.defaultBlockState()); // hero stands on a path
        }, t -> {
            if (t == 4) {
                AttributeInstance move = hero().getAttribute(Attributes.MOVEMENT_SPEED);
                PILGRIM_MOD[0] = move != null && move.hasModifier(Arcanum.id("pilgrim_path"));
            }
        }, () -> {
            if (!PILGRIM_MOD[0]) return "no +15% speed on path";
            return null;
        });
    }

    private static final boolean[] PILGRIM_MOD = {false};

    private static TestDef magnetism() {
        return timed("magnetism", 25, () -> {
            hero().setItemInHand(InteractionHand.MAIN_HAND, ench(Items.IRON_SWORD, ArcanumEnchantments.MAGNETISM, 1));
            magnetItem = new ItemEntity(level(), 2.3, 201.0, 0.5, new ItemStack(Items.IRON_NUGGET));
            magnetItem.setDefaultPickUpDelay();
            level().addFreshEntity(magnetItem);
        }, t -> {
            if (t == 12) { // pickup delay (10t) over; the pull should have moved it at least once
                MAGNET_MOVED[0] = !magnetItem.isAlive() || magnetItem.getX() < 2.2;
            }
        }, () -> {
            if (!MAGNET_MOVED[0]) return "item not pulled toward hero (x " + magnetItem.getX() + ")";
            return null;
        });
    }

    private static final boolean[] MAGNET_MOVED = {false};
    private static ItemEntity magnetItem;

    // ------------------------------------------------------------------
    // STRIDE
    // ------------------------------------------------------------------

    private static TestDef cometfall() {
        return timed("cometfall", 15, () -> {
            ItemStack trident = ench(Items.TRIDENT, ArcanumEnchantments.COMETFALL, 1);
            hero().setItemInHand(InteractionHand.MAIN_HAND, trident);
            cometZ = zombieAt(2.5, 0.5);
            hero().startAutoSpinAttack(40, 1.0F, trident);
            hero().absSnapTo(0.5, 204.5, 0.5, 0F, 0F); // airborne during the spin
        }, t -> {}, () -> {
            if (cometZ == null || !cometZ.isAlive()) return "target zombie gone";
            float loss = 20.0F - cometZ.getHealth();
            if (loss <= 3.2F) return "no riptide-landing slam damage (loss " + loss + ")";
            return null;
        });
    }

    private static Zombie cometZ;

    // ------------------------------------------------------------------
    // METHOD / BOON tools
    // ------------------------------------------------------------------

    private static TestDef feller() {
        return timed("feller", 3, () -> {
            hero().setItemInHand(InteractionHand.MAIN_HAND, ench(Items.IRON_AXE, ArcanumEnchantments.FELLER, 1));
            for (int y = 201; y <= 205; y++) setBlock(5, y, 0, Blocks.OAK_LOG.defaultBlockState());
            hero().gameMode.destroyBlock(new BlockPos(5, 201, 0));
        }, t -> {}, () -> {
            for (int y = 202; y <= 205; y++) {
                if (!block(5, y, 0).isAir()) return "log column above break not felled (y=" + y + ")";
            }
            return null;
        });
    }

    private static TestDef trencher() {
        return timed("trencher", 3, () -> {
            hero().setItemInHand(InteractionHand.MAIN_HAND, ench(Items.IRON_SHOVEL, ArcanumEnchantments.TRENCHER, 1));
            hero().setShiftKeyDown(true);
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    setBlock(6 + dx, 201, dz, Blocks.DIRT.defaultBlockState());
            hero().gameMode.destroyBlock(new BlockPos(6, 201, 0));
        }, t -> {}, () -> {
            for (int dx = -1; dx <= 1; dx++)
                for (int dz = -1; dz <= 1; dz++)
                    if (!block(6 + dx, 201, dz).isAir()) return "sneak-mined 3x3 incomplete (" + dx + "," + dz + ")";
            return null;
        });
    }

    private static TestDef replanter() {
        return timed("replanter", 3, () -> {
            hero().setItemInHand(InteractionHand.MAIN_HAND, ench(Items.IRON_HOE, ArcanumEnchantments.REPLANTER, 1));
            hero().getInventory().add(new ItemStack(Items.WHEAT_SEEDS, 4));
            CropBlock crop = (CropBlock) Blocks.WHEAT;
            setBlock(7, 201, 0, crop.getStateForAge(crop.getMaxAge()));
            hero().gameMode.destroyBlock(new BlockPos(7, 201, 0));
        }, t -> {}, () -> {
            BlockState state = block(7, 201, 0);
            CropBlock crop = (CropBlock) Blocks.WHEAT;
            if (!state.is(Blocks.WHEAT)) return "crop not replanted (" + state + ")";
            if (crop.isMaxAge(state)) return "replanted at full age";
            int seeds = 0;
            for (int i = 0; i < hero().getInventory().getContainerSize(); i++) {
                ItemStack stack = hero().getInventory().getItem(i);
                if (stack.is(Items.WHEAT_SEEDS)) seeds += stack.getCount();
            }
            if (seeds != 3) return "seed not consumed (count " + seeds + ")";
            return null;
        });
    }

    private static TestDef kilnHands() {
        return timed("kiln_hands", 10, () -> {
            hero().setItemInHand(InteractionHand.MAIN_HAND, ench(Items.IRON_PICKAXE, ArcanumEnchantments.KILN_HANDS, 1));
        }, t -> {
            if (t >= 9) return;
            setBlock(8, 201, 0, Blocks.IRON_ORE.defaultBlockState());
            hero().gameMode.destroyBlock(new BlockPos(8, 201, 0));
            boolean ingot = itemNear(8.5, 201, 0.5, 9.0, Items.IRON_INGOT);
            discardItemsNear(8.5, 201, 0.5, 9.0);
            if (ingot) KILN_INGOT_SEEN[0] = true;
        }, () -> {
            if (!KILN_INGOT_SEEN[0]) return "no smelted ingot in 9 ore drops (70% each)";
            return null;
        });
    }

    private static final boolean[] KILN_INGOT_SEEN = {false};
}
