package com.aura.lamplight.folio.menu;

import com.aura.lamplight.folio.component.ModDataComponents;
import com.aura.lamplight.folio.item.SpellbookItem;
import com.aura.lamplight.folio.spell.Spell;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.resources.Identifier;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * A virtual container that materializes the spell ids stored on a spellbook
 * as real school scroll stacks. This lets vanilla's slot move/swap/quick-move
 * code operate on spellbook pages for free, while the book itself only ever
 * persists a list of spell ids.
 */
public final class SpellbookContainer extends SimpleContainer {

    private final Player player;
    private final SpellbookItem.@org.jspecify.annotations.Nullable Equipped equipped;
    private final int capacity;
    private boolean writing;

    public SpellbookContainer(final Player player, final SpellbookItem.@org.jspecify.annotations.Nullable Equipped equipped) {
        // Always reserve the full page count. The client can construct this
        // container before the equipped book's attachment has synced, so
        // deriving the slot count from the book would desync the menu.
        super(capacityOf(equipped));
        this.player = player;
        this.equipped = equipped;
        this.capacity = this.getContainerSize();
        if (equipped != null) {
            List<Identifier> spells = SpellbookItem.getSpells(equipped.stack());
            for (int i = 0; i < Math.min(this.capacity, spells.size()); i++) {
                Spell spell = com.aura.lamplight.folio.spell.Spells.byId(spells.get(i));
                if (spell != null) {
                    this.getItems().set(i, SpellbookItem.scrollFor(spell));
                }
            }
        }
    }

    private static int capacityOf(final SpellbookItem.@org.jspecify.annotations.Nullable Equipped equipped) {
        return equipped == null ? SpellbookItem.CAPACITY : SpellbookItem.capacity(equipped.stack());
    }

    public SpellbookItem.@org.jspecify.annotations.Nullable Equipped equipped() {
        return this.equipped;
    }

    public int capacity() {
        return this.capacity;
    }

    @Override
    public void setChanged() {
        if (this.writing || this.player.level().isClientSide() || this.equipped == null) {
            return;
        }
        this.writeBack();
    }

    /** Persists the current page stacks into the book and resyncs it. */
    public void writeBack() {
        if (this.player.level().isClientSide() || this.equipped == null || this.writing) {
            return;
        }
        this.writing = true;
        try {
            List<Identifier> ids = new ArrayList<>();
            for (int i = 0; i < this.capacity; i++) {
                Spell spell = SpellbookItem.spellOfScroll(this.getItem(i));
                if (spell != null && !ids.contains(spell.id())) {
                    ids.add(spell.id());
                }
            }

            ItemStack book = this.equipped.stack();
            book.set(ModDataComponents.SPELLBOOK_SPELLS, List.copyOf(ids));
            SpellbookItem.setSelected(book, SpellbookItem.getSelected(book));

            // Rebuild pages in canonical school-scroll form. A scroll whose
            // host school did not match its spell gets normalized here.
            for (int i = 0; i < this.capacity; i++) {
                Spell spell = i < ids.size() ? com.aura.lamplight.folio.spell.Spells.byId(ids.get(i)) : null;
                ItemStack canonical = spell == null ? ItemStack.EMPTY : SpellbookItem.scrollFor(spell);
                this.getItems().set(i, canonical);
            }

            this.equipped.sync(this.player);
        } finally {
            this.writing = false;
        }
    }

    @Override
    public boolean stillValid(final Player p) {
        return true;
    }

    @Override
    public void clearContent() {
        super.clearContent();
        this.setChanged();
    }
}
