package com.aura.lamplight.folio.spell;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Base class for every spell that a scroll, or a spellbook page, can hold.
 * To add a new spell:
 *
 * <ol>
 *   <li>Create a class that extends {@code Spell}, e.g. {@code FireballSpell}.</li>
 *   <li>Give it a public no-args constructor that calls
 *       {@code super(id, displayName, school)} - see {@link FrostBoltSpell} or
 *       {@link SlowingAuraSpell} for examples.</li>
 *   <li>Implement {@link #cast(ServerLevel, Player, ItemStack)} with the
 *       actual effect.</li>
 *   <li>Register an instance of it in {@link Spells}.</li>
 * </ol>
 *
 * <p>Spells are looked up at cast time by the {@link Identifier} stored in
 * an item's {@link com.aura.lamplight.folio.component.ModDataComponents#SPELL}
 * component, so any number of spells can share the same underlying item
 * without new item registrations.</p>
 *
 * <p>Casting from a scroll is always free and instant; casting from a
 * spellbook uses the {@link #manaCost() mana cost}, {@link #castTime()
 * cast time}, {@link #cooldownTicks() cooldown}, and channel metadata below.</p>
 */
public abstract class Spell {

    private final Identifier id;
    private final Component name;
    private final SpellSchool school;
    private final int manaCost;
    private final int castTime;
    private final int cooldownTicks;
    private final boolean interruptible;
    private final boolean channeled;

    protected Spell(final Identifier id, final Component name, final SpellSchool school) {
        this(id, name, school, 10, 20, 40, true, false);
    }

    protected Spell(
        final Identifier id,
        final Component name,
        final SpellSchool school,
        final int manaCost,
        final int castTime,
        final int cooldownTicks,
        final boolean interruptible
    ) {
        this(id, name, school, manaCost, castTime, cooldownTicks, interruptible, false);
    }

    protected Spell(
        final Identifier id,
        final Component name,
        final SpellSchool school,
        final int manaCost,
        final int castTime,
        final int cooldownTicks,
        final boolean interruptible,
        final boolean channeled
    ) {
        this.id = id;
        this.name = name;
        this.school = school;
        this.manaCost = manaCost;
        this.castTime = castTime;
        this.cooldownTicks = cooldownTicks;
        this.interruptible = interruptible;
        this.channeled = channeled;
    }

    /** The school this spell belongs to. */
    public final SpellSchool school() {
        return school;
    }

    /** The unique id used to store/identify this spell, e.g. {@code lamplight:frost_bolt}. */
    public final Identifier id() {
        return id;
    }

    /** Display name shown in tooltips (e.g. "Frost Bolt"). */
    public final Component name() {
        return name;
    }

    /** Mana spent when the spell starts casting from a spellbook. */
    public final int manaCost() {
        return manaCost;
    }

    /** Ticks spent casting before the effect fires. Zero means instant. */
    public final int castTime() {
        return castTime;
    }

    /** Ticks before this spell can be cast again after it resolves. */
    public final int cooldownTicks() {
        return cooldownTicks;
    }

    /** Whether taking damage cancels this spell's cast. */
    public final boolean interruptible() {
        return interruptible;
    }

    /** Whether this spell ticks repeatedly while being channelled. */
    public final boolean channeled() {
        return channeled;
    }

    /**
     * Performs the actual spell effect. Only ever called server-side.
     *
     * @param level      the server level the caster is in
     * @param caster     the player who used the scroll or spellbook
     * @param sourceItem a stack representing the source (the consumed scroll,
     *                   or a virtual scroll for the spellbook page)
     */
    public abstract void cast(ServerLevel level, Player caster, ItemStack sourceItem);

    /**
     * Called roughly every ten ticks while a {@link #channeled() channeled}
     * spell is being cast. The default implementation does nothing.
     */
    public void castTick(final ServerLevel level, final Player caster, final ItemStack sourceItem) {
    }

    @Override
    public String toString() {
        return "Spell[" + id + "]";
    }
}
