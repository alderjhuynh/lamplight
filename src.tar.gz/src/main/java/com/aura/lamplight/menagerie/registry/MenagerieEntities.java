package com.aura.lamplight.menagerie.registry;

import com.aura.lamplight.menagerie.Menagerie;
import com.aura.lamplight.menagerie.crow.CrowEntity;
import com.aura.lamplight.menagerie.raccoon.RaccoonEntity;
// import com.aura.lamplight.menagerie.wisp.WispEntity; // Wisp disabled for now.
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.level.levelgen.Heightmap;

import net.minecraft.world.entity.SpawnPlacements;

public final class MenagerieEntities {
    public static final EntityType<CrowEntity> CROW = register("crow",
            EntityType.Builder.of(CrowEntity::new, MobCategory.CREATURE).sized(0.45F, 0.45F).clientTrackingRange(10));
    public static final Item CROW_SPAWN_EGG = registerEgg("crow_spawn_egg", CROW, 0x0D111C, 0x1C2030);
    public static final EntityType<RaccoonEntity> RACCOON = register("raccoon",
            EntityType.Builder.of(RaccoonEntity::new, MobCategory.CREATURE).sized(0.8F, 0.9F).clientTrackingRange(10));
    public static final Item RACCOON_SPAWN_EGG = registerEgg("raccoon_spawn_egg", RACCOON, 0x5A4B3E, 0xD8CFC4);
    // Wisp disabled for now.
    // public static final EntityType<WispEntity> WISP = register("wisp",
    //         EntityType.Builder.of(WispEntity::new, MobCategory.AMBIENT).sized(0.7F, 0.9F).clientTrackingRange(10));
    // public static final Item WISP_SPAWN_EGG = registerEgg("wisp_spawn_egg", WISP, 0x173A5E, 0x8FD8FF);

    private MenagerieEntities() {
    }

    private static <T extends net.minecraft.world.entity.Entity> EntityType<T> register(String name, EntityType.Builder<T> builder) {
        Identifier id = Menagerie.id(name);
        EntityType<T> type = builder.build(ResourceKey.create(Registries.ENTITY_TYPE, id));
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, id, type);
    }

    private static Item registerEgg(String name, EntityType<?> type, int base, int spots) {
        Identifier id = Menagerie.id(name);
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        Item egg = new SpawnEggItem(new Item.Properties().setId(key).spawnEgg(type));
        return Registry.register(BuiltInRegistries.ITEM, key, egg);
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(CROW, CrowEntity.bakeAttributes().build());
        SpawnPlacements.register(CROW, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, CrowEntity::canCrowSpawn);

        FabricDefaultAttributeRegistry.register(RACCOON, RaccoonEntity.bakeAttributes().build());
        SpawnPlacements.register(RACCOON, SpawnPlacementTypes.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (type, level, reason, pos, random) -> level.getRawBrightness(pos, 0) > 8);

        // Wisp disabled for now.
        // FabricDefaultAttributeRegistry.register(WISP, WispEntity.bakeAttributes().build());
        // SpawnPlacements.register(WISP, SpawnPlacementTypes.NO_RESTRICTIONS, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, WispEntity::canWispSpawn);
    }
}
