package com.aura.lamplight.mixin.arcanum;

import com.aura.lamplight.arcanum.server.RebuildHandler;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Chain Load: a loaded crossbow can be fired twice before needing a recharge.
 * RebuildHandler snapshots the loaded projectiles before the shot and re-arms the
 * component after the first shot; the second shot consumes the snapshot for real.
 */
@Mixin(CrossbowItem.class)
public class ChainLoadMixin {

    @Inject(method = "use", at = @At("HEAD"))
    private void lamplight$chainLoadReset(Level level, Player player, InteractionHand hand,
                                          CallbackInfoReturnable<net.minecraft.world.InteractionResult> cir) {
        RebuildHandler.onCrossbowUse(player, player.getItemInHand(hand));
    }

    @Inject(method = "releaseUsing", at = @At("HEAD"))
    private void lamplight$chainLoadSnapshot(ItemStack stack, Level level, LivingEntity entity, int timeLeft,
                                             CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof Player player) {
            RebuildHandler.onCrossbowReleaseHead(player, stack);
        }
    }

    @Inject(method = "releaseUsing", at = @At("RETURN"))
    private void lamplight$chainLoadReArm(ItemStack stack, Level level, LivingEntity entity, int timeLeft,
                                          CallbackInfoReturnable<Boolean> cir) {
        if (entity instanceof Player player) {
            RebuildHandler.onCrossbowReleaseTail(player, stack);
        }
    }
}
