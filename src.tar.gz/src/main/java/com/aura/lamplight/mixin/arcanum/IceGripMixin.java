package com.aura.lamplight.mixin.arcanum;

import com.aura.lamplight.arcanum.enchantment.ArcanumEnchantments;
import com.aura.lamplight.arcanum.server.RebuildHandler;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Ice grip shared by Sure Footed and Grip Spikes: no slipping on ice.
 * Hooks the friction->speed conversion; ice (friction > 0.6) behaves like normal ground.
 */
@Mixin(LivingEntity.class)
public class IceGripMixin {

    @Inject(method = "getFrictionInfluencedSpeed", at = @At("HEAD"), cancellable = true)
    private void lamplight$iceGrip(float friction, CallbackInfoReturnable<Float> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (!(self instanceof Player player) || !player.onGround()) return;
        int grip = RebuildHandler.armorLvl(player, ArcanumEnchantments.SURE_FOOTED) > 0
                || RebuildHandler.armorLvl(player, ArcanumEnchantments.GRIP_SPIKES) > 0 ? 1 : 0;
        if (grip == 0 || friction <= 0.6F) return;
        cir.setReturnValue(player.getSpeed());
    }
}
