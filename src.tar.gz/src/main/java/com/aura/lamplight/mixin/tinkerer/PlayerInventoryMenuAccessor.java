package com.aura.lamplight.mixin.tinkerer;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.InventoryMenu;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Player.class)
public interface PlayerInventoryMenuAccessor {
	@Accessor("inventoryMenu")
	@Final
	@Mutable
	void setInventoryMenu(InventoryMenu menu);
}
