package com.aura.lamplight.wayfarer;

import com.aura.lamplight.wayfarer.atlas.AtlasSyncPayload;
import com.aura.lamplight.wayfarer.waystone.ModBlockEntities;
import com.aura.lamplight.wayfarer.waystone.ModBlocks;
import com.aura.lamplight.wayfarer.waystone.ModParticles;
import com.aura.lamplight.wayfarer.waystone.WaystoneChanneling;
import com.aura.lamplight.wayfarer.waystone.WaystoneChannelBeginPayload;
import com.aura.lamplight.wayfarer.waystone.WaystoneChannelEndPayload;
import com.aura.lamplight.wayfarer.waystone.WaystoneNamePayload;
import com.aura.lamplight.wayfarer.waystone.WaystoneNamingPayload;
import com.aura.lamplight.wayfarer.waystone.WaystoneTravelListPayload;
import com.aura.lamplight.wayfarer.waystone.WaystoneTravelPayload;
import net.fabricmc.api.ModInitializer;

import net.minecraft.resources.Identifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Wayfarer implements ModInitializer {
	public static final String MOD_ID = "lamplight";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ModDataComponents.initialize();
		ModBlocks.register();
		ModBlockEntities.register();
		ModItems.register();
		ModMenus.register();
		WayfarerSounds.register();
		ModParticles.register();
		WaystoneTravelListPayload.initialize();
		WaystoneTravelPayload.initialize();
		WaystoneNamingPayload.initialize();
		WaystoneNamePayload.initialize();
		WaystoneChannelBeginPayload.initialize();
		WaystoneChannelEndPayload.initialize();
		WaystoneChanneling.initialize();
		AtlasSyncPayload.initialize();
		LOGGER.info("[wayfarer] common init");
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
